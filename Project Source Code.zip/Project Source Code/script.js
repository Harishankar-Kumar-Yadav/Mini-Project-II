// alert("loading");
function addNewWEField() {
    //   console.log("Adding new field");
  
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("weField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let weOb = document.getElementById("we");
    let weAddButtonOb = document.getElementById("weAddButton");
  
    weOb.insertBefore(newNode, weAddButtonOb);
  }
  
  function addNewAQField() {
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("eqField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let aqOb = document.getElementById("aq");
    let aqAddButtonOb = document.getElementById("aqAddButton");
  
    aqOb.insertBefore(newNode, aqAddButtonOb);
  }
  function addNewCTField() {
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("ctField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let ctOb = document.getElementById("ct");
    let ctAddButtonOb = document.getElementById("ctAddButton");
  
    ctOb.insertBefore(newNode, ctAddButtonOb);
  }
  function addNewHBField() {
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("hbField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let hbOb = document.getElementById("hb");
    let hbAddButtonOb = document.getElementById("hbAddButton");
  
    hbOb.insertBefore(newNode, hbAddButtonOb);
  }
  function addNewCRTField() {
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("crtField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let crtOb = document.getElementById("crt");
    let crtAddButtonOb = document.getElementById("crtAddButton");
  
    crtOb.insertBefore(newNode, crtAddButtonOb);
  }
  function addNewSKField() {
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("skField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let skOb = document.getElementById("sk");
    let skAddButtonOb = document.getElementById("skAddButton");
  
    skOb.insertBefore(newNode, skAddButtonOb);
  }
  function addNewLGField() {
    let newNode = document.createElement("textarea");
    newNode.classList.add("form-control");
    newNode.classList.add("lgField");
    newNode.classList.add("mt-2");
    newNode.setAttribute("rows", 3);
    newNode.setAttribute("placeholder", "Enter here");
  
    let lgOb = document.getElementById("lg");
    let lgAddButtonOb = document.getElementById("lgAddButton");
  
    lgOb.insertBefore(newNode, lgAddButtonOb);
  }

  
  //generating cv
  function generateCV() {
    // console.log("generating CV");
  
    let nameField = document.getElementById("nameField").value;
  
    let nameT1 = document.getElementById("nameT1");
  
    nameT1.innerHTML = nameField;
  
    //direct
  
    document.getElementById("nameT2").innerHTML = nameField;
  
    //contact
    document.getElementById("contactT").innerHTML = document.getElementById(
      "contactField"
    ).value;
     //Email
     document.getElementById("emailT").innerHTML = document.getElementById(
      "emailField"
    ).value;
  
    //address
    document.getElementById("addressT").innerHTML = document.getElementById(
      "addressField"
    ).value;
    document.getElementById("fbT").innerHTML = document.getElementById(
      "fbField"
    ).value;
    document.getElementById("instaT").innerHTML = document.getElementById(
      "instaField"
    ).value;
    document.getElementById("linkedT").innerHTML = document.getElementById(
      "linkedField"
    ).value;
  
    //objective
  
    document.getElementById("objectiveT").innerHTML = document.getElementById(
      "objectiveField"
    ).value;
  
    //we
  
    let wes = document.getElementsByClassName("weField");
  
    let str = "";
  
    for (let e of wes) {
      str = str + `<li> ${e.value} </li>`;
    }
  
    document.getElementById("weT").innerHTML = str;
  
    //aq
  
    let aqs = document.getElementsByClassName("eqField");
  
    let str1 = "";
  
    for (let e of aqs) {
      str1 += `<li> ${e.value} </li>`;
    }
  
    document.getElementById("aqT").innerHTML = str1;
    //ct
    let cts = document.getElementsByClassName("ctField");
  
    let str2 = "";
  
    for (let e of cts) {
      str2 += `<li> ${e.value} </li>`;
    }
  
    document.getElementById("ctT").innerHTML = str2;
    //hb
    let hbs = document.getElementsByClassName("hbField");
  
    let str3 = "";
  
    for (let e of hbs) {
      str3 += `<li> ${e.value} </li>`;
    }
  
    document.getElementById("hbT").innerHTML = str3;
     //Certificates
     let crts = document.getElementsByClassName("crtField");
  
     let str4 = "";
   
     for (let e of crts) {
       str4 += `<li> ${e.value} </li>`;
     }
   
     document.getElementById("crtT").innerHTML = str4;
     //skills
     let sks = document.getElementsByClassName("skField");
  
    let str5 = "";
  
    for (let e of sks) {
      str5 += `<li> ${e.value} </li>`;
    }
  
    document.getElementById("skT").innerHTML = str5;
    //language
    let lgs = document.getElementsByClassName("lgField");
  
    let str6 = "";
  
    for (let e of lgs) {
      str6 += `<li> ${e.value} </li>`;
    }
  
    document.getElementById("lgT").innerHTML = str6;
  
    //code for setting image
  
    let file = document.getElementById("imgField").files[0];
  
    console.log(file);
  
    let reader = new FileReader();
  
    reader.readAsDataURL(file);
  
    console.log(reader.result);
  
    //set the image to template
  
    reader.onloadend = function () {
      document.getElementById("imgTemplate").src = reader.result;
    };
  
    document.getElementById("cv-form").style.display = "none";
    document.getElementById("cv-template").style.display = "block";
  }
  
  //print cv
  function printCV() {
    window.print();
  }
    